

"""
## Installation
Run the following to install:

'''python
pip install okdoodle
"""

## Usage
'''Python
from okdoodle import sayhello

# Generate "Hello, world!"
sayhello()

# Generate "Hello, Everybody!"
sayhello("Everybody")